import java.sql.*;




import java.sql.*;
public class JdbcConnectivity {
    public static void main(String[] args) {
    
        

        try {
            // Load the JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
                // JDBC URL, username, and password of MySQL server
             String url = "jdbc:mysql://localhost:3306/mit";//database name mit
         String username = "root";
          String password = "root";
          
                  
            Connection con = DriverManager.getConnection(url, username, password);


            // insert into table biodata
            String q = "insert into biodata(fname,surname,address) values(?,?,?)";//table name biodata
           PreparedStatement ps=con.prepareStatement(q);
         
         ps.setString(1, "talib");
          ps.setString(2, "baloch");
           ps.setString(3, "padian");
           
            ps.executeUpdate();
            System.out.println("Successfully added \n check database");
             //statement.close();
            con.close();
        } 
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}


    public static void main(String[] args)throws Exception {
       
            // Load the JDBC driver
           Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");


            // Establish a connection
            Connection sun= DriverManager.getConnection("jdbc:obdc mit");

            Statement st= sun.createStatement();

            // Insert a new employee
            ResultSet result = st.executeQuery("select id,fname,surname,adress from biodata");

            // Retrieve and display all employees
        
    while(result.next()){
    
                int id = result.getInt("id");
                String fname = result.getString("fname");
                String surname = result.getString("surname");
                String address = result.getString("address");

                System.out.println(id + "\t\t" + fname + "\t\t" + surname + "\t\t" + address);
            }
    result.close();
    st.close();
    
        }
    }
